 module.exports = {
    assetPrefix: ".",
  };
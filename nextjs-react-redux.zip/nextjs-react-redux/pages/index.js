import React from 'react';
import { connect } from 'react-redux';
import { decrementCounter, incrementCounter } from '../redux/actions/counterActions';
import Link from "next/link"
import Router from 'next/router'

class App extends React.Component {

    static getInitialProps({ store }) { }

    constructor(props) {
        super(props);
    }

    render() {

        let date = new Date();
        return (
            <div>
                <button onClick={this.props.incrementCounter}>Increment</button>
                <button onClick={this.props.decrementCounter}>Decrement</button>
                <h1>{this.props.counter}</h1>
                <Link href="./page1"><a>First Post</a></Link>
                <br />
                <span onClick={() => Router.push('./page2')}>Second Post</span>

                <p>Some time: {date.toJSON()}</p>

          {/*       <amp-timeago
                    width="0"
                    height="15"
                    datetime={date.toJSON()}
                    layout="responsive"
                >
                </amp-timeago>
                <amp-img
                    alt="Mountains"
                    fallback=""
                    width="550"
                    height="368"
                    layout="responsive"
                    src="https://amp.dev/static/inline-examples/images/mountains.jpg"
                ></amp-img> */}
    

            </div>
        );
    }
}

const mapStateToProps = state => ({
    counter: state.counter.value
});

const mapDispatchToProps = {
    incrementCounter: incrementCounter,
    decrementCounter: decrementCounter,
};
export default connect(mapStateToProps, mapDispatchToProps)(App);


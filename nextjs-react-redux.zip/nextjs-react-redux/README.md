# Nextjs-React-Redux-Example

A Simple Counter App made with next.js, react and redux. 

To run the app:

```
npm install
npm run dev
```

[Detailed Explanation](https://dev.to/waqasabbasi/server-side-rendered-app-with-next-js-react-and-redux-38gf)

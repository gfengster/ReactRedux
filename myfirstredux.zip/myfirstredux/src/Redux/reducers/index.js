// src/Redux/reducers/index.js
import counterReducer from "./counter";
import authReducer from "./auth";
import {combineReducers} from "redux";

const allReducers = combineReducers(
    {
        counterR: counterReducer,
        authR: authReducer,
    }
);
export default allReducers;
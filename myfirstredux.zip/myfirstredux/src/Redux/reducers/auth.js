
// src/Redux/reducers/authReducer.js

const authReducer = (state = {auth: false}, action) => {

    let status = false;
    switch (action.type) {
      case "LOG_IN":
        status = true;
        break;
      case "LOG_OUT":
        status = false;
        break;
      default:
    }

   
    return {
      ...state,
      auth: status
    }
  };
  export default authReducer;
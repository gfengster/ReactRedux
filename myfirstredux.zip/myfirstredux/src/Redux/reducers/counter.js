// src/Redux/reducers/counterReducer.js

const counterReducer = (state = {counter:0}, action) => {
    let count = state.counter;
    switch (action.type) {
      case "INCREMENT":
        count ++;
        break;
      case "DECREMENT":
        count --;
        break;
      case "RESET":
        count = 0;
        break;
      default:
    }

    return {
      ...state,
      counter: count
    }
  };
  export default counterReducer;